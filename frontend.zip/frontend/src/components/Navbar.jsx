import { Link, useLocation } from "react-router-dom";
import { useAdmin } from "../App";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "./ui/dropdown-menu";
import { Menu, X, FileText, Info, ChevronDown } from "lucide-react";
import { useState } from "react";

const categories = [
  { id: "creencias", name: "Creencias" },
  { id: "leyendas-urbanas", name: "Leyendas Urbanas" },
  { id: "creepypasta", name: "Creepypasta" },
  { id: "lost-media", name: "Lost Media" },
  { id: "teorias-conspirativas", name: "Teorías Conspirativas" },
  { id: "mitos", name: "Mitos" },
  { id: "historias-reales", name: "Historias Reales" },
  { id: "fantasia", name: "Fantasía" },
  { id: "misterios", name: "Misterios" },
  { id: "rituales-amarres", name: "Rituales y Amarres" },
  { id: "magia-hechizos", name: "Magia y Hechizos" },
  { id: "practicas-mentales", name: "Prácticas Mentales" },
];

const Navbar = () => {
  const { admin } = useAdmin();
  const location = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const isActive = (path) => location.pathname === path;

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-[#050505]/95 backdrop-blur-sm border-b border-[#1a1a1a]">
      <div className="max-w-6xl mx-auto px-6">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link 
            to="/" 
            className="flex items-center gap-3 group"
            data-testid="nav-logo"
          >
            <div className="w-8 h-8 border border-primary/50 flex items-center justify-center group-hover:border-primary transition-colors">
              <span className="font-mono text-xs text-primary">217</span>
            </div>
            <div className="hidden sm:block">
              <span className="font-display text-lg text-[#e5e5e5] tracking-wide">Registro 217</span>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center gap-6">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <button className="flex items-center gap-1 font-ui text-sm text-[#a3a3a3] hover:text-[#e5e5e5] transition-colors" data-testid="nav-categories">
                  Archivos
                  <ChevronDown size={14} />
                </button>
              </DropdownMenuTrigger>
              <DropdownMenuContent className="bg-[#0a0a0a] border-[#262626] max-h-[400px] overflow-y-auto">
                {categories.map((cat) => (
                  <DropdownMenuItem 
                    key={cat.id}
                    asChild
                    className="text-[#d4d4d4] hover:text-[#e5e5e5] hover:bg-[#171717] cursor-pointer"
                  >
                    <Link to={`/categoria/${cat.id}`}>{cat.name}</Link>
                  </DropdownMenuItem>
                ))}
              </DropdownMenuContent>
            </DropdownMenu>

            <Link 
              to="/sobre-el-archivo" 
              className={`font-ui text-sm transition-colors ${
                isActive('/sobre-el-archivo') ? 'text-primary' : 'text-[#a3a3a3] hover:text-[#e5e5e5]'
              }`}
              data-testid="nav-about"
            >
              Sobre el Archivo
            </Link>

            {admin && (
              <Link 
                to="/admin/dashboard" 
                className="font-ui text-xs text-primary border border-primary/30 px-3 py-1 hover:bg-primary/10 transition-colors"
                data-testid="nav-admin"
              >
                Panel Admin
              </Link>
            )}
          </div>

          {/* Mobile Menu Button */}
          <button 
            className="md:hidden p-2 text-[#a3a3a3]"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            data-testid="mobile-menu-toggle"
          >
            {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <div className="md:hidden py-4 border-t border-[#1a1a1a]">
            <div className="flex flex-col gap-3">
              <p className="font-ui text-xs text-[#525252] uppercase tracking-wider mb-2">Archivos</p>
              <div className="grid grid-cols-2 gap-2">
                {categories.map((cat) => (
                  <Link 
                    key={cat.id}
                    to={`/categoria/${cat.id}`}
                    className="font-ui text-sm text-[#a3a3a3] hover:text-[#e5e5e5] py-1"
                    onClick={() => setMobileMenuOpen(false)}
                  >
                    {cat.name}
                  </Link>
                ))}
              </div>
              
              <div className="border-t border-[#1a1a1a] pt-4 mt-2 flex flex-col gap-3">
                <Link 
                  to="/sobre-el-archivo"
                  className="font-ui text-sm text-[#a3a3a3] hover:text-[#e5e5e5]"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  Sobre el Archivo
                </Link>
                {admin && (
                  <Link 
                    to="/admin/dashboard"
                    className="font-ui text-sm text-primary"
                    onClick={() => setMobileMenuOpen(false)}
                  >
                    Panel Admin
                  </Link>
                )}
              </div>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
};

export default Navbar;
