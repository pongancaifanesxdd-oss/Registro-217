import { Link } from "react-router-dom";
import { FileText, Clock } from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import { es } from "date-fns/locale";

const categoryLabels = {
  "creencias": "Creencias",
  "leyendas-urbanas": "Leyendas Urbanas",
  "creepypasta": "Creepypasta",
  "lost-media": "Lost Media",
  "teorias-conspirativas": "Teorías Conspirativas",
  "mitos": "Mitos",
  "historias-reales": "Historias Reales",
  "fantasia": "Fantasía",
  "misterios": "Misterios",
  "rituales-amarres": "Rituales y Amarres",
  "magia-hechizos": "Magia y Hechizos",
  "practicas-mentales": "Prácticas Mentales",
};

const tagColors = {
  "real": "bg-green-900/30 text-green-400 border-green-800/50",
  "creencia": "bg-amber-900/30 text-amber-400 border-amber-800/50",
  "ficcion": "bg-blue-900/30 text-blue-400 border-blue-800/50",
};

const tagLabels = {
  "real": "Real",
  "creencia": "Creencia",
  "ficcion": "Ficción",
};

const EntryCard = ({ entry }) => {
  const formatDate = (dateString) => {
    try {
      const date = new Date(dateString);
      return formatDistanceToNow(date, { addSuffix: true, locale: es });
    } catch {
      return "";
    }
  };

  const truncateContent = (content, maxLength = 120) => {
    if (!content) return "";
    if (content.length <= maxLength) return content;
    return content.substring(0, maxLength).trim() + "...";
  };

  return (
    <Link 
      to={`/registro/${entry.entry_id}`}
      className="block bg-[#0a0a0a] border border-[#1a1a1a] p-5 group hover:border-[#333] transition-all duration-300"
      data-testid={`entry-card-${entry.entry_id}`}
    >
      {/* Header */}
      <div className="flex items-start justify-between gap-3 mb-3">
        <span className="font-mono text-[10px] text-[#525252] uppercase tracking-widest">
          {categoryLabels[entry.category] || entry.category}
        </span>
        <span className={`font-mono text-[10px] px-2 py-0.5 border ${tagColors[entry.tag] || tagColors.ficcion}`}>
          {tagLabels[entry.tag] || entry.tag}
        </span>
      </div>

      {/* Image */}
      {entry.image_url && (
        <div className="mb-4 -mx-5 -mt-1">
          <img 
            src={entry.image_url} 
            alt={entry.title}
            className="w-full h-40 object-cover grayscale group-hover:grayscale-0 transition-all duration-500 opacity-80 group-hover:opacity-100"
          />
        </div>
      )}

      {/* Title */}
      <h3 className="font-display text-lg text-[#e5e5e5] mb-2 group-hover:text-primary transition-colors duration-300 leading-tight">
        {entry.title}
      </h3>

      {/* Summary/Content Preview */}
      <p className="font-body text-sm text-[#737373] leading-relaxed mb-4">
        {truncateContent(entry.summary || entry.content)}
      </p>

      {/* Footer */}
      <div className="flex items-center justify-between pt-3 border-t border-[#1a1a1a]">
        <div className="flex items-center gap-1 text-[#525252]">
          <FileText size={12} />
          <span className="font-mono text-[10px]">REG-{entry.entry_id.slice(-6).toUpperCase()}</span>
        </div>
        <div className="flex items-center gap-1 text-[#525252]">
          <Clock size={12} />
          <span className="font-mono text-[10px]">{formatDate(entry.created_at)}</span>
        </div>
      </div>
    </Link>
  );
};

export default EntryCard;
