import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import axios from "axios";
import { API } from "../App";
import Navbar from "../components/Navbar";
import EntryCard from "../components/EntryCard";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Search, FileText, Archive, AlertTriangle, ChevronRight } from "lucide-react";

const categoryImages = {
  "creencias": "https://images.unsplash.com/photo-1572336624242-9891ff7378c2?w=600&auto=format&fit=crop",
  "leyendas-urbanas": "https://images.unsplash.com/photo-1630906183978-7764df75c820?w=600&auto=format&fit=crop",
  "creepypasta": "https://images.unsplash.com/photo-1542507815265-3e0105099f95?w=600&auto=format&fit=crop",
  "lost-media": "https://images.pexels.com/photos/6968874/pexels-photo-6968874.jpeg?w=600&auto=format&fit=crop",
  "teorias-conspirativas": "https://images.unsplash.com/photo-1516110833967-0b5716ca1387?w=600&auto=format&fit=crop",
  "mitos": "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=600&auto=format&fit=crop",
  "historias-reales": "https://images.unsplash.com/photo-1457369804613-52c61a468e7d?w=600&auto=format&fit=crop",
  "fantasia": "https://images.unsplash.com/photo-1518562180175-34a163b1a9a6?w=600&auto=format&fit=crop",
  "misterios": "https://images.unsplash.com/photo-1509248961895-a6fc2a214368?w=600&auto=format&fit=crop",
  "rituales-amarres": "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=600&auto=format&fit=crop",
  "magia-hechizos": "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=600&auto=format&fit=crop",
  "practicas-mentales": "https://images.unsplash.com/photo-1506126613408-eca07ce68773?w=600&auto=format&fit=crop",
};

const HomePage = () => {
  const [entries, setEntries] = useState([]);
  const [categories, setCategories] = useState([]);
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const [entriesRes, categoriesRes, statsRes] = await Promise.all([
        axios.get(`${API}/entries?limit=6`),
        axios.get(`${API}/categories`),
        axios.get(`${API}/stats`)
      ]);
      setEntries(entriesRes.data.entries || []);
      setCategories(categoriesRes.data.categories || []);
      setStats(statsRes.data);
    } catch (error) {
      console.error("Error fetching data:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleSearch = (e) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      window.location.href = `/categoria/all?search=${encodeURIComponent(searchQuery)}`;
    }
  };

  return (
    <div className="min-h-screen bg-[#050505]">
      <Navbar />
      
      {/* Hero Section */}
      <section className="relative pt-16 min-h-[80vh] flex items-center">
        <div className="absolute inset-0 opacity-5">
          <div className="absolute inset-0" style={{
            backgroundImage: `repeating-linear-gradient(0deg, transparent, transparent 50px, #1a1a1a 50px, #1a1a1a 51px),
                             repeating-linear-gradient(90deg, transparent, transparent 50px, #1a1a1a 50px, #1a1a1a 51px)`
          }} />
        </div>
        
        <div className="relative max-w-6xl mx-auto px-6 py-24">
          <div className="max-w-2xl">
            {/* Classification Badge */}
            <div className="inline-flex items-center gap-2 mb-8 border border-primary/30 px-3 py-1">
              <div className="w-2 h-2 bg-primary animate-pulse" />
              <span className="font-mono text-xs text-primary tracking-widest">ARCHIVO CLASIFICADO</span>
            </div>

            <h1 
              className="font-display text-5xl md:text-7xl text-[#e5e5e5] tracking-tight mb-4 animate-fade-in-up"
              data-testid="hero-title"
            >
              Registro<br />
              <span className="text-primary">217</span>
            </h1>
            
            <p className="font-mono text-sm text-[#525252] mb-6 tracking-wider animate-fade-in-up animate-delay-100">
              ARCHIVOS CLASIFICADOS DE LO INEXPLICABLE
            </p>
            
            <p className="font-body text-lg text-[#a3a3a3] leading-relaxed mb-8 animate-fade-in-up animate-delay-200">
              Un repositorio de lo prohibido y lo olvidado. Aquí se resguardan los secretos 
              que la razón no puede explicar: creencias ancestrales, leyendas urbanas, 
              misterios sin resolver y fenómenos que desafían toda comprensión.
            </p>

            {/* Search */}
            <form onSubmit={handleSearch} className="flex gap-2 mb-12 animate-fade-in-up animate-delay-300">
              <div className="relative flex-1">
                <Search size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#525252]" />
                <Input
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="bg-[#0a0a0a] border-[#1a1a1a] pl-10 font-mono text-sm h-11 focus:border-primary/50"
                  placeholder="Buscar en el archivo..."
                  data-testid="search-input"
                />
              </div>
              <Button type="submit" className="bg-primary hover:bg-primary/90 h-11 px-6 font-mono text-sm">
                Buscar
              </Button>
            </form>

            {/* Stats */}
            {stats && (
              <div className="flex gap-8 animate-fade-in-up animate-delay-400">
                <div className="border-l-2 border-primary/30 pl-4">
                  <p className="font-mono text-2xl text-primary">{stats.total_entries}</p>
                  <p className="font-mono text-[10px] text-[#525252] uppercase tracking-wider">Registros</p>
                </div>
                <div className="border-l-2 border-[#1a1a1a] pl-4">
                  <p className="font-mono text-2xl text-[#737373]">{categories.length}</p>
                  <p className="font-mono text-[10px] text-[#525252] uppercase tracking-wider">Categorías</p>
                </div>
                <div className="border-l-2 border-[#1a1a1a] pl-4">
                  <p className="font-mono text-2xl text-[#737373]">3</p>
                  <p className="font-mono text-[10px] text-[#525252] uppercase tracking-wider">Etiquetas</p>
                </div>
              </div>
            )}
          </div>
        </div>
      </section>

      {/* Disclaimer */}
      <section className="py-8 bg-amber-950/10 border-y border-amber-900/20">
        <div className="max-w-6xl mx-auto px-6">
          <div className="flex items-start gap-4">
            <AlertTriangle size={20} className="text-amber-500 flex-shrink-0 mt-0.5" />
            <div>
              <p className="font-ui text-sm text-amber-200/80">
                <strong>Aviso:</strong> Este archivo contiene registros de diversa naturaleza. 
                Algunos documentan eventos reales y verificables, otros representan creencias populares 
                y tradiciones culturales, y otros son obras de ficción. Cada registro está etiquetado 
                correspondientemente. El lector debe ejercer su propio criterio.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Categories Grid */}
      <section className="py-20 bg-[#050505]">
        <div className="max-w-6xl mx-auto px-6">
          <div className="flex items-center gap-3 mb-12">
            <Archive size={20} className="text-primary" />
            <h2 className="font-display text-2xl text-[#e5e5e5]">Índice de Archivos</h2>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {categories.map((cat, index) => (
              <Link 
                key={cat.id}
                to={`/categoria/${cat.id}`}
                className="group relative h-32 overflow-hidden bg-[#0a0a0a] border border-[#1a1a1a] hover:border-primary/30 transition-all duration-300"
                style={{ animationDelay: `${index * 50}ms` }}
                data-testid={`category-${cat.id}`}
              >
                <img 
                  src={categoryImages[cat.id]} 
                  alt={cat.name}
                  className="absolute inset-0 w-full h-full object-cover opacity-20 grayscale group-hover:opacity-30 group-hover:grayscale-0 transition-all duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#050505] via-[#050505]/80 to-transparent" />
                <div className="relative h-full flex flex-col justify-end p-4">
                  <h3 className="font-display text-sm text-[#e5e5e5] group-hover:text-primary transition-colors">
                    {cat.name}
                  </h3>
                  <p className="font-mono text-[10px] text-[#525252]">
                    {cat.count} {cat.count === 1 ? 'registro' : 'registros'}
                  </p>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Recent Entries */}
      <section className="py-20 bg-[#0a0a0a]/30">
        <div className="max-w-6xl mx-auto px-6">
          <div className="flex items-center justify-between mb-12">
            <div className="flex items-center gap-3">
              <FileText size={20} className="text-primary" />
              <h2 className="font-display text-2xl text-[#e5e5e5]">Registros Recientes</h2>
            </div>
            <Link 
              to="/categoria/all" 
              className="hidden md:flex items-center gap-1 text-[#525252] hover:text-primary transition-colors font-mono text-sm"
            >
              Ver todos
              <ChevronRight size={14} />
            </Link>
          </div>

          {loading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[1, 2, 3, 4, 5, 6].map(i => (
                <div key={i} className="skeleton h-48" />
              ))}
            </div>
          ) : entries.length === 0 ? (
            <div className="text-center py-16 border border-[#1a1a1a]">
              <FileText size={40} className="mx-auto mb-4 text-[#333]" />
              <p className="font-mono text-sm text-[#525252]">
                No hay registros en el archivo
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {entries.map((entry, index) => (
                <div 
                  key={entry.entry_id} 
                  className="animate-fade-in-up"
                  style={{ animationDelay: `${index * 100}ms` }}
                >
                  <EntryCard entry={entry} />
                </div>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 border-t border-[#1a1a1a]">
        <div className="max-w-6xl mx-auto px-6">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6">
            <div className="flex items-center gap-3">
              <div className="w-6 h-6 border border-primary/30 flex items-center justify-center">
                <span className="font-mono text-[8px] text-primary">217</span>
              </div>
              <span className="font-mono text-xs text-[#525252]">REGISTRO 217</span>
            </div>
            <div className="flex items-center gap-6">
              <Link to="/sobre-el-archivo" className="font-mono text-xs text-[#525252] hover:text-[#737373] transition-colors">
                Sobre el Archivo
              </Link>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default HomePage;
