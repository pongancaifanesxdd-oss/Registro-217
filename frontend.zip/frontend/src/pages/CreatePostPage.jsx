import { useState, useRef } from "react";
import { useNavigate, Link } from "react-router-dom";
import axios from "axios";
import { API, useAuth } from "../App";
import { toast } from "sonner";
import Navbar from "../components/Navbar";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Textarea } from "../components/ui/textarea";
import { Label } from "../components/ui/label";
import { Switch } from "../components/ui/switch";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "../components/ui/select";
import { ImagePlus, X, ChevronLeft } from "lucide-react";

const categories = [
  { id: "creencias", name: "Creencias" },
  { id: "leyendas-urbanas", name: "Leyendas Urbanas" },
  { id: "creepypasta", name: "Creepypasta" },
  { id: "lost-media", name: "Lost Media" },
];

const CreatePostPage = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const fileInputRef = useRef(null);
  
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [category, setCategory] = useState("");
  const [isAnonymous, setIsAnonymous] = useState(false);
  const [pseudonym, setPseudonym] = useState("");
  const [imageUrl, setImageUrl] = useState("");
  const [uploading, setUploading] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  const handleImageUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith("image/")) {
      toast.error("Solo se permiten imágenes");
      return;
    }

    if (file.size > 5 * 1024 * 1024) {
      toast.error("Imagen muy grande (máx 5MB)");
      return;
    }

    setUploading(true);
    const formData = new FormData();
    formData.append("file", file);

    try {
      const response = await axios.post(`${API}/upload`, formData, {
        withCredentials: true,
        headers: { "Content-Type": "multipart/form-data" }
      });
      setImageUrl(response.data.url);
      toast.success("Imagen subida");
    } catch (error) {
      toast.error("Error al subir imagen");
    } finally {
      setUploading(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!title.trim() || !content.trim() || !category) {
      toast.error("Completa todos los campos requeridos");
      return;
    }

    setSubmitting(true);

    try {
      const response = await axios.post(
        `${API}/posts`,
        {
          title: title.trim(),
          content: content.trim(),
          category,
          is_anonymous: isAnonymous,
          pseudonym: isAnonymous ? pseudonym.trim() || null : null,
          image_url: imageUrl || null,
        },
        { withCredentials: true }
      );

      toast.success("¡Historia publicada!");
      navigate(`/post/${response.data.post_id}`);
    } catch (error) {
      toast.error(error.response?.data?.detail || "Error al publicar");
    } finally {
      setSubmitting(false);
    }
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-[#050505]">
        <Navbar />
        <div className="pt-32 text-center px-6">
          <p className="font-body text-[#a3a3a3] text-lg mb-4">
            Debes iniciar sesión para escribir una historia
          </p>
          <Link to="/login">
            <Button className="btn-primary">Iniciar Sesión</Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#050505]">
      <Navbar />

      <div className="pt-24 pb-16 max-w-2xl mx-auto px-6 md:px-12">
        <Link 
          to="/"
          className="inline-flex items-center gap-2 text-[#a3a3a3] hover:text-[#e5e5e5] mb-8 transition-colors"
        >
          <ChevronLeft size={18} />
          <span className="font-ui text-sm">Volver</span>
        </Link>

        <h1 className="font-display text-3xl md:text-4xl text-[#e5e5e5] tracking-tight mb-2">
          Escribir Historia
        </h1>
        <p className="font-ui text-[#a3a3a3] mb-8">
          Comparte tu relato con la comunidad
        </p>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Title */}
          <div>
            <Label htmlFor="title" className="font-ui text-sm text-[#a3a3a3] mb-2 block">
              Título *
            </Label>
            <Input
              id="title"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="input-dark font-display text-xl"
              placeholder="El título de tu historia..."
              required
              data-testid="post-title-input"
            />
          </div>

          {/* Category */}
          <div>
            <Label htmlFor="category" className="font-ui text-sm text-[#a3a3a3] mb-2 block">
              Categoría *
            </Label>
            <Select value={category} onValueChange={setCategory} required>
              <SelectTrigger className="input-dark" data-testid="category-select">
                <SelectValue placeholder="Selecciona una categoría" />
              </SelectTrigger>
              <SelectContent className="bg-[#0a0a0a] border-[#262626]">
                {categories.map((cat) => (
                  <SelectItem 
                    key={cat.id} 
                    value={cat.id}
                    className="text-[#d4d4d4] hover:bg-[#171717] cursor-pointer"
                  >
                    {cat.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Content */}
          <div>
            <Label htmlFor="content" className="font-ui text-sm text-[#a3a3a3] mb-2 block">
              Historia *
            </Label>
            <Textarea
              id="content"
              value={content}
              onChange={(e) => setContent(e.target.value)}
              className="input-dark textarea-story"
              placeholder="Escribe tu historia aquí..."
              required
              data-testid="post-content-input"
            />
          </div>

          {/* Image Upload */}
          <div>
            <Label className="font-ui text-sm text-[#a3a3a3] mb-2 block">
              Imagen (opcional)
            </Label>
            
            {imageUrl ? (
              <div className="relative">
                <img 
                  src={imageUrl} 
                  alt="Preview" 
                  className="w-full max-h-64 object-cover"
                />
                <button
                  type="button"
                  onClick={() => setImageUrl("")}
                  className="absolute top-2 right-2 p-2 bg-[#050505]/80 text-[#e5e5e5] hover:bg-[#050505]"
                >
                  <X size={16} />
                </button>
              </div>
            ) : (
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                disabled={uploading}
                className="w-full border border-dashed border-[#262626] hover:border-primary/50 py-12 flex flex-col items-center gap-2 transition-colors"
              >
                <ImagePlus size={32} className="text-[#737373]" />
                <span className="font-ui text-sm text-[#737373]">
                  {uploading ? "Subiendo..." : "Haz clic para subir imagen"}
                </span>
              </button>
            )}
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              onChange={handleImageUpload}
              className="hidden"
            />
          </div>

          {/* Anonymous Toggle */}
          <div className="bg-[#0a0a0a] border border-[#262626]/30 p-6">
            <div className="flex items-center justify-between mb-4">
              <div>
                <Label htmlFor="anonymous" className="font-ui text-sm text-[#e5e5e5]">
                  Publicar de forma anónima
                </Label>
                <p className="font-ui text-xs text-[#737373] mt-1">
                  Tu nombre de usuario no será visible
                </p>
              </div>
              <Switch
                id="anonymous"
                checked={isAnonymous}
                onCheckedChange={setIsAnonymous}
                data-testid="anonymous-toggle"
              />
            </div>

            {isAnonymous && (
              <div>
                <Label htmlFor="pseudonym" className="font-ui text-sm text-[#a3a3a3] mb-2 block">
                  Seudónimo (opcional)
                </Label>
                <Input
                  id="pseudonym"
                  value={pseudonym}
                  onChange={(e) => setPseudonym(e.target.value)}
                  className="input-dark"
                  placeholder="Un nombre alternativo..."
                  data-testid="pseudonym-input"
                />
              </div>
            )}
          </div>

          {/* Submit */}
          <div className="flex gap-4">
            <Button
              type="button"
              variant="outline"
              onClick={() => navigate(-1)}
              className="border-[#262626] text-[#a3a3a3] hover:bg-[#171717] flex-1"
            >
              Cancelar
            </Button>
            <Button
              type="submit"
              disabled={submitting || !title.trim() || !content.trim() || !category}
              className="btn-primary flex-1"
              data-testid="submit-post"
            >
              {submitting ? "Publicando..." : "Publicar Historia"}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default CreatePostPage;
