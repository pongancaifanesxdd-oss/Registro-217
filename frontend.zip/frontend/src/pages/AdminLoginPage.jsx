import { useState, useEffect } from "react";
import { useNavigate, Link } from "react-router-dom";
import axios from "axios";
import { API, useAdmin } from "../App";
import { toast } from "sonner";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Label } from "../components/ui/label";
import { Lock, Mail } from "lucide-react";

const AdminLoginPage = () => {
  const navigate = useNavigate();
  const { admin, login } = useAdmin();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (admin) {
      navigate("/admin/dashboard");
    }
  }, [admin, navigate]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      const response = await axios.post(
        `${API}/admin/login`,
        { email, password },
        { withCredentials: true }
      );
      login(response.data);
      toast.success("Acceso concedido");
      navigate("/admin/dashboard");
    } catch (error) {
      toast.error(error.response?.data?.detail || "Credenciales inválidas");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#050505] flex items-center justify-center px-6">
      <div className="w-full max-w-sm">
        {/* Logo */}
        <Link to="/" className="block text-center mb-12">
          <div className="inline-flex items-center gap-3">
            <div className="w-10 h-10 border border-primary/50 flex items-center justify-center">
              <span className="font-mono text-sm text-primary">217</span>
            </div>
            <span className="font-display text-xl text-[#e5e5e5]">Registro 217</span>
          </div>
        </Link>

        <div className="bg-[#0a0a0a] border border-[#1a1a1a] p-8">
          <div className="text-center mb-8">
            <h1 className="font-display text-xl text-[#e5e5e5] mb-2">
              Acceso Restringido
            </h1>
            <p className="font-mono text-xs text-[#525252]">
              SOLO ADMINISTRADORES
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <Label htmlFor="email" className="font-mono text-xs text-[#525252] mb-2 block">
                CORREO
              </Label>
              <div className="relative">
                <Mail size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#525252]" />
                <Input
                  id="email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="bg-[#050505] border-[#1a1a1a] pl-10 font-mono text-sm"
                  placeholder="admin@registro217.com"
                  required
                  data-testid="admin-email-input"
                />
              </div>
            </div>

            <div>
              <Label htmlFor="password" className="font-mono text-xs text-[#525252] mb-2 block">
                CONTRASEÑA
              </Label>
              <div className="relative">
                <Lock size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#525252]" />
                <Input
                  id="password"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="bg-[#050505] border-[#1a1a1a] pl-10 font-mono text-sm"
                  placeholder="••••••••"
                  required
                  data-testid="admin-password-input"
                />
              </div>
            </div>

            <Button
              type="submit"
              disabled={loading}
              className="w-full bg-primary hover:bg-primary/90 font-mono text-sm mt-6"
              data-testid="admin-login-submit"
            >
              {loading ? "Verificando..." : "Acceder"}
            </Button>
          </form>
        </div>

        <p className="text-center mt-6">
          <Link to="/" className="font-mono text-xs text-[#525252] hover:text-[#737373] transition-colors">
            ← Volver al archivo
          </Link>
        </p>
      </div>
    </div>
  );
};

export default AdminLoginPage;
