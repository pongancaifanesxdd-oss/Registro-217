import { useState, useRef, useEffect } from "react";
import { useNavigate, Link } from "react-router-dom";
import axios from "axios";
import { API, useAdmin } from "../App";
import { toast } from "sonner";
import Navbar from "../components/Navbar";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Textarea } from "../components/ui/textarea";
import { Label } from "../components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "../components/ui/select";
import { ImagePlus, X, ChevronLeft } from "lucide-react";

const categories = [
  { id: "creencias", name: "Creencias" },
  { id: "leyendas-urbanas", name: "Leyendas Urbanas" },
  { id: "creepypasta", name: "Creepypasta" },
  { id: "lost-media", name: "Lost Media" },
  { id: "teorias-conspirativas", name: "Teorías Conspirativas" },
  { id: "mitos", name: "Mitos" },
  { id: "historias-reales", name: "Historias Reales" },
  { id: "fantasia", name: "Fantasía" },
  { id: "misterios", name: "Misterios" },
  { id: "rituales-amarres", name: "Rituales y Amarres" },
  { id: "magia-hechizos", name: "Magia y Hechizos" },
  { id: "practicas-mentales", name: "Prácticas Mentales" },
];

const tags = [
  { id: "real", name: "Real", desc: "Eventos documentados" },
  { id: "creencia", name: "Creencia", desc: "Tradiciones populares" },
  { id: "ficcion", name: "Ficción", desc: "Relatos inventados" },
];

const CreateEntryPage = () => {
  const navigate = useNavigate();
  const { admin, loading: authLoading } = useAdmin();
  const fileInputRef = useRef(null);
  
  const [title, setTitle] = useState("");
  const [summary, setSummary] = useState("");
  const [content, setContent] = useState("");
  const [category, setCategory] = useState("");
  const [tag, setTag] = useState("");
  const [imageUrl, setImageUrl] = useState("");
  const [uploading, setUploading] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (!authLoading && !admin) {
      navigate("/admin");
    }
  }, [admin, authLoading, navigate]);

  const handleImageUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith("image/")) {
      toast.error("Solo se permiten imágenes");
      return;
    }

    if (file.size > 5 * 1024 * 1024) {
      toast.error("Imagen muy grande (máx 5MB)");
      return;
    }

    setUploading(true);
    const formData = new FormData();
    formData.append("file", file);

    try {
      const response = await axios.post(`${API}/upload`, formData, {
        withCredentials: true,
        headers: { "Content-Type": "multipart/form-data" }
      });
      setImageUrl(response.data.url);
      toast.success("Imagen subida");
    } catch (error) {
      toast.error("Error al subir imagen");
    } finally {
      setUploading(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!title.trim() || !content.trim() || !category || !tag) {
      toast.error("Completa todos los campos requeridos");
      return;
    }

    setSubmitting(true);

    try {
      const response = await axios.post(
        `${API}/entries`,
        {
          title: title.trim(),
          summary: summary.trim() || null,
          content: content.trim(),
          category,
          tag,
          image_url: imageUrl || null,
        },
        { withCredentials: true }
      );

      toast.success("Registro creado");
      navigate(`/registro/${response.data.entry_id}`);
    } catch (error) {
      toast.error(error.response?.data?.detail || "Error al crear registro");
    } finally {
      setSubmitting(false);
    }
  };

  if (authLoading) {
    return (
      <div className="min-h-screen bg-[#050505] flex items-center justify-center">
        <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (!admin) return null;

  return (
    <div className="min-h-screen bg-[#050505]">
      <Navbar />

      <div className="pt-24 pb-16 max-w-2xl mx-auto px-6">
        <Link 
          to="/admin/dashboard"
          className="inline-flex items-center gap-2 text-[#525252] hover:text-[#737373] mb-8 transition-colors"
        >
          <ChevronLeft size={16} />
          <span className="font-mono text-sm">Volver al panel</span>
        </Link>

        <h1 className="font-display text-3xl text-[#e5e5e5] mb-2">Nuevo Registro</h1>
        <p className="font-mono text-xs text-[#525252] mb-8">Agregar entrada al archivo</p>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Title */}
          <div>
            <Label htmlFor="title" className="font-mono text-xs text-[#525252] mb-2 block">
              TÍTULO *
            </Label>
            <Input
              id="title"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="bg-[#0a0a0a] border-[#1a1a1a] font-display text-lg"
              placeholder="Título del registro..."
              required
              data-testid="entry-title-input"
            />
          </div>

          {/* Category & Tag */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label className="font-mono text-xs text-[#525252] mb-2 block">
                CATEGORÍA *
              </Label>
              <Select value={category} onValueChange={setCategory} required>
                <SelectTrigger className="bg-[#0a0a0a] border-[#1a1a1a]" data-testid="category-select">
                  <SelectValue placeholder="Seleccionar..." />
                </SelectTrigger>
                <SelectContent className="bg-[#0a0a0a] border-[#1a1a1a] max-h-[300px]">
                  {categories.map((cat) => (
                    <SelectItem 
                      key={cat.id} 
                      value={cat.id}
                      className="text-[#d4d4d4] hover:bg-[#171717]"
                    >
                      {cat.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label className="font-mono text-xs text-[#525252] mb-2 block">
                ETIQUETA *
              </Label>
              <Select value={tag} onValueChange={setTag} required>
                <SelectTrigger className="bg-[#0a0a0a] border-[#1a1a1a]" data-testid="tag-select">
                  <SelectValue placeholder="Seleccionar..." />
                </SelectTrigger>
                <SelectContent className="bg-[#0a0a0a] border-[#1a1a1a]">
                  {tags.map((t) => (
                    <SelectItem 
                      key={t.id} 
                      value={t.id}
                      className="text-[#d4d4d4] hover:bg-[#171717]"
                    >
                      {t.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Summary */}
          <div>
            <Label htmlFor="summary" className="font-mono text-xs text-[#525252] mb-2 block">
              RESUMEN (opcional)
            </Label>
            <Textarea
              id="summary"
              value={summary}
              onChange={(e) => setSummary(e.target.value)}
              className="bg-[#0a0a0a] border-[#1a1a1a] font-body min-h-[80px]"
              placeholder="Breve descripción del registro..."
              data-testid="entry-summary-input"
            />
          </div>

          {/* Content */}
          <div>
            <Label htmlFor="content" className="font-mono text-xs text-[#525252] mb-2 block">
              CONTENIDO *
            </Label>
            <Textarea
              id="content"
              value={content}
              onChange={(e) => setContent(e.target.value)}
              className="bg-[#0a0a0a] border-[#1a1a1a] font-body min-h-[300px] leading-relaxed"
              placeholder="Contenido completo del registro..."
              required
              data-testid="entry-content-input"
            />
          </div>

          {/* Image Upload */}
          <div>
            <Label className="font-mono text-xs text-[#525252] mb-2 block">
              IMAGEN (opcional)
            </Label>
            
            {imageUrl ? (
              <div className="relative">
                <img 
                  src={imageUrl} 
                  alt="Preview" 
                  className="w-full max-h-48 object-cover"
                />
                <button
                  type="button"
                  onClick={() => setImageUrl("")}
                  className="absolute top-2 right-2 p-2 bg-[#050505]/80 text-[#e5e5e5] hover:bg-[#050505]"
                >
                  <X size={16} />
                </button>
              </div>
            ) : (
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                disabled={uploading}
                className="w-full border border-dashed border-[#1a1a1a] hover:border-primary/30 py-8 flex flex-col items-center gap-2 transition-colors"
              >
                <ImagePlus size={24} className="text-[#525252]" />
                <span className="font-mono text-xs text-[#525252]">
                  {uploading ? "Subiendo..." : "Subir imagen"}
                </span>
              </button>
            )}
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              onChange={handleImageUpload}
              className="hidden"
            />
          </div>

          {/* Submit */}
          <div className="flex gap-4 pt-4">
            <Button
              type="button"
              variant="outline"
              onClick={() => navigate("/admin/dashboard")}
              className="border-[#1a1a1a] flex-1"
            >
              Cancelar
            </Button>
            <Button
              type="submit"
              disabled={submitting || !title.trim() || !content.trim() || !category || !tag}
              className="bg-primary hover:bg-primary/90 flex-1"
              data-testid="submit-entry"
            >
              {submitting ? "Guardando..." : "Crear Registro"}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default CreateEntryPage;
