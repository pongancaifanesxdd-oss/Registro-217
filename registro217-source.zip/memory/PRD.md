# Registro 217 - PRD

## Problema Original
Sitio web tipo archivo/biblioteca digital (no comunidad abierta) para documentar lo inexplicable.

**Nombre:** Registro 217
**Eslogan:** Archivos clasificados de lo inexplicable

## Cambios desde MVP inicial
- ❌ Removido: Registro público de usuarios
- ❌ Removido: Sistema de comentarios
- ❌ Removido: Sistema de likes
- ❌ Removido: Publicación por usuarios
- ✅ Solo admin puede crear/editar/eliminar contenido
- ✅ 12 categorías expandidas
- ✅ Sistema de etiquetas (Real, Creencia, Ficción)
- ✅ Sección "Sobre el Archivo"
- ✅ Aviso de contenido

## Categorías (12)
1. Creencias
2. Leyendas Urbanas
3. Creepypasta
4. Lost Media
5. Teorías Conspirativas
6. Mitos
7. Historias Reales
8. Fantasía
9. Misterios
10. Rituales y Amarres
11. Magia y Hechizos
12. Prácticas Mentales

## Sistema de Etiquetas
- **Real**: Eventos documentados o verificables
- **Creencia**: Tradiciones y creencias populares
- **Ficción**: Relatos inventados

## Arquitectura
- **Backend**: FastAPI + MongoDB
- **Frontend**: React + Tailwind CSS
- **Auth**: Solo admin (JWT)
- **Collections**: admins, entries

## Credenciales Admin
- Email: admin@registro217.com
- Password: admin123
- Panel: /admin

## Implementado (21 Enero 2026)
- [x] Sitio público de solo lectura
- [x] Panel de administración protegido
- [x] CRUD de registros (solo admin)
- [x] 12 categorías de contenido
- [x] Sistema de etiquetas
- [x] Búsqueda de registros
- [x] Filtrado por categoría y etiqueta
- [x] Subida de imágenes
- [x] Página "Sobre el Archivo"
- [x] Aviso de contenido real/ficción
- [x] Diseño oscuro minimalista

## Próximos Pasos
1. Agregar más contenido al archivo
2. Considerar sistema de destacados
3. Añadir contador de visitas por registro
