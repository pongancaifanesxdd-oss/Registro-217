from fastapi import FastAPI, APIRouter, HTTPException, Depends, Request, Response, UploadFile, File
from fastapi.responses import JSONResponse
from dotenv import load_dotenv
from starlette.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient
import os
import logging
from pathlib import Path
from pydantic import BaseModel, Field, ConfigDict, EmailStr
from typing import List, Optional
import uuid
from datetime import datetime, timezone, timedelta
import bcrypt
import jwt
import base64

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

# MongoDB connection
mongo_url = os.environ['MONGO_URL']
client = AsyncIOMotorClient(mongo_url)
db = client[os.environ['DB_NAME']]

# JWT Secret
JWT_SECRET = os.environ['JWT_SECRET']
JWT_ALGORITHM = "HS256"
JWT_EXPIRY_DAYS = 7

# Create the main app
app = FastAPI()

# Create a router with the /api prefix
api_router = APIRouter(prefix="/api")

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# ============== MODELS ==============

class AdminLogin(BaseModel):
    email: EmailStr
    password: str

class UserResponse(BaseModel):
    model_config = ConfigDict(extra="ignore")
    user_id: str
    email: str
    name: str
    role: str = "admin"

class EntryCreate(BaseModel):
    title: str
    content: str
    category: str
    tag: str  # Real, Creencia, Ficción
    summary: Optional[str] = None
    image_url: Optional[str] = None

class EntryUpdate(BaseModel):
    title: Optional[str] = None
    content: Optional[str] = None
    category: Optional[str] = None
    tag: Optional[str] = None
    summary: Optional[str] = None
    image_url: Optional[str] = None

class EntryResponse(BaseModel):
    model_config = ConfigDict(extra="ignore")
    entry_id: str
    title: str
    content: str
    category: str
    tag: str
    summary: Optional[str] = None
    image_url: Optional[str] = None
    created_at: datetime
    updated_at: datetime

# ============== CATEGORIES & TAGS ==============

VALID_CATEGORIES = [
    "creencias",
    "leyendas-urbanas", 
    "creepypasta",
    "lost-media",
    "teorias-conspirativas",
    "mitos",
    "historias-reales",
    "fantasia",
    "misterios",
    "rituales-amarres",
    "magia-hechizos",
    "practicas-mentales"
]

VALID_TAGS = ["real", "creencia", "ficcion"]

CATEGORY_INFO = {
    "creencias": {"name": "Creencias", "description": "Creencias populares y supersticiones"},
    "leyendas-urbanas": {"name": "Leyendas Urbanas", "description": "Historias transmitidas de generación en generación"},
    "creepypasta": {"name": "Creepypasta", "description": "Relatos de terror nacidos en internet"},
    "lost-media": {"name": "Lost Media", "description": "Contenido perdido o difícil de encontrar"},
    "teorias-conspirativas": {"name": "Teorías Conspirativas", "description": "Teorías alternativas sobre eventos y fenómenos"},
    "mitos": {"name": "Mitos", "description": "Relatos tradicionales de culturas ancestrales"},
    "historias-reales": {"name": "Historias Reales", "description": "Eventos documentados y verificables"},
    "fantasia": {"name": "Fantasía", "description": "Relatos de ficción y mundos imaginarios"},
    "misterios": {"name": "Misterios", "description": "Casos sin resolver y enigmas"},
    "rituales-amarres": {"name": "Rituales y Amarres", "description": "Prácticas rituales y tradiciones"},
    "magia-hechizos": {"name": "Magia y Hechizos", "description": "Tradiciones mágicas y esotéricas"},
    "practicas-mentales": {"name": "Prácticas Mentales", "description": "Espiritualismo, misticismo y chamanismo"}
}

# ============== AUTH HELPERS ==============

def hash_password(password: str) -> str:
    return bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')

def verify_password(password: str, hashed: str) -> bool:
    return bcrypt.checkpw(password.encode('utf-8'), hashed.encode('utf-8'))

def create_jwt_token(user_id: str) -> str:
    expiry = datetime.now(timezone.utc) + timedelta(days=JWT_EXPIRY_DAYS)
    payload = {"user_id": user_id, "exp": expiry}
    return jwt.encode(payload, JWT_SECRET, algorithm=JWT_ALGORITHM)

def decode_jwt_token(token: str) -> Optional[str]:
    try:
        payload = jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALGORITHM])
        return payload.get("user_id")
    except jwt.ExpiredSignatureError:
        return None
    except jwt.InvalidTokenError:
        return None

async def get_admin_user(request: Request) -> dict:
    """Only admins can access protected routes"""
    session_token = request.cookies.get("session_token")
    
    if not session_token:
        auth_header = request.headers.get("Authorization")
        if auth_header and auth_header.startswith("Bearer "):
            session_token = auth_header.split(" ")[1]
    
    if not session_token:
        raise HTTPException(status_code=401, detail="No autenticado")
    
    user_id = decode_jwt_token(session_token)
    if not user_id:
        raise HTTPException(status_code=401, detail="Token inválido o expirado")
    
    user = await db.admins.find_one({"user_id": user_id}, {"_id": 0})
    if not user or user.get("role") != "admin":
        raise HTTPException(status_code=403, detail="Acceso solo para administradores")
    
    return user

# ============== ADMIN AUTH ROUTES ==============

@api_router.post("/admin/login")
async def admin_login(login_data: AdminLogin, response: Response):
    """Admin login - only route to access the system"""
    admin = await db.admins.find_one({"email": login_data.email}, {"_id": 0})
    
    if not admin:
        raise HTTPException(status_code=401, detail="Credenciales inválidas")
    
    if not verify_password(login_data.password, admin["password"]):
        raise HTTPException(status_code=401, detail="Credenciales inválidas")
    
    token = create_jwt_token(admin["user_id"])
    
    response.set_cookie(
        key="session_token",
        value=token,
        httponly=True,
        secure=True,
        samesite="none",
        path="/",
        max_age=JWT_EXPIRY_DAYS * 24 * 60 * 60
    )
    
    return {
        "user_id": admin["user_id"],
        "email": admin["email"],
        "name": admin["name"],
        "role": "admin",
        "token": token
    }

@api_router.get("/admin/me")
async def get_admin_me(request: Request):
    admin = await get_admin_user(request)
    return {
        "user_id": admin["user_id"],
        "email": admin["email"],
        "name": admin["name"],
        "role": "admin"
    }

@api_router.post("/admin/logout")
async def admin_logout(response: Response):
    response.delete_cookie(key="session_token", path="/", samesite="none", secure=True)
    return {"message": "Sesión cerrada"}

# ============== ENTRIES ROUTES (Admin only for CUD) ==============

@api_router.post("/entries", response_model=EntryResponse)
async def create_entry(entry_data: EntryCreate, request: Request):
    """Create new entry - Admin only"""
    await get_admin_user(request)
    
    if entry_data.category not in VALID_CATEGORIES:
        raise HTTPException(status_code=400, detail=f"Categoría inválida")
    
    if entry_data.tag.lower() not in VALID_TAGS:
        raise HTTPException(status_code=400, detail=f"Etiqueta inválida. Use: Real, Creencia, Ficción")
    
    entry_id = f"entry_{uuid.uuid4().hex[:12]}"
    now = datetime.now(timezone.utc).isoformat()
    
    entry_doc = {
        "entry_id": entry_id,
        "title": entry_data.title,
        "content": entry_data.content,
        "category": entry_data.category,
        "tag": entry_data.tag.lower(),
        "summary": entry_data.summary,
        "image_url": entry_data.image_url,
        "created_at": now,
        "updated_at": now
    }
    
    await db.entries.insert_one(entry_doc)
    
    entry_doc["created_at"] = datetime.fromisoformat(now)
    entry_doc["updated_at"] = datetime.fromisoformat(now)
    
    return EntryResponse(**entry_doc)

@api_router.get("/entries")
async def get_entries(
    category: Optional[str] = None,
    tag: Optional[str] = None,
    search: Optional[str] = None,
    page: int = 1,
    limit: int = 20
):
    """Get all entries - Public access"""
    query = {}
    
    if category and category in VALID_CATEGORIES:
        query["category"] = category
    
    if tag and tag.lower() in VALID_TAGS:
        query["tag"] = tag.lower()
    
    if search:
        query["$or"] = [
            {"title": {"$regex": search, "$options": "i"}},
            {"content": {"$regex": search, "$options": "i"}},
            {"summary": {"$regex": search, "$options": "i"}}
        ]
    
    skip = (page - 1) * limit
    
    entries = await db.entries.find(query, {"_id": 0}).sort("created_at", -1).skip(skip).limit(limit).to_list(limit)
    total = await db.entries.count_documents(query)
    
    for entry in entries:
        if isinstance(entry.get("created_at"), str):
            entry["created_at"] = datetime.fromisoformat(entry["created_at"])
        if isinstance(entry.get("updated_at"), str):
            entry["updated_at"] = datetime.fromisoformat(entry["updated_at"])
    
    return {
        "entries": entries,
        "total": total,
        "page": page,
        "pages": (total + limit - 1) // limit if total > 0 else 1
    }

@api_router.get("/entries/{entry_id}")
async def get_entry(entry_id: str):
    """Get single entry - Public access"""
    entry = await db.entries.find_one({"entry_id": entry_id}, {"_id": 0})
    
    if not entry:
        raise HTTPException(status_code=404, detail="Registro no encontrado")
    
    if isinstance(entry.get("created_at"), str):
        entry["created_at"] = datetime.fromisoformat(entry["created_at"])
    if isinstance(entry.get("updated_at"), str):
        entry["updated_at"] = datetime.fromisoformat(entry["updated_at"])
    
    return entry

@api_router.put("/entries/{entry_id}")
async def update_entry(entry_id: str, entry_data: EntryUpdate, request: Request):
    """Update entry - Admin only"""
    await get_admin_user(request)
    
    entry = await db.entries.find_one({"entry_id": entry_id}, {"_id": 0})
    if not entry:
        raise HTTPException(status_code=404, detail="Registro no encontrado")
    
    update_data = {k: v for k, v in entry_data.model_dump().items() if v is not None}
    
    if "category" in update_data and update_data["category"] not in VALID_CATEGORIES:
        raise HTTPException(status_code=400, detail="Categoría inválida")
    
    if "tag" in update_data:
        if update_data["tag"].lower() not in VALID_TAGS:
            raise HTTPException(status_code=400, detail="Etiqueta inválida")
        update_data["tag"] = update_data["tag"].lower()
    
    update_data["updated_at"] = datetime.now(timezone.utc).isoformat()
    
    await db.entries.update_one({"entry_id": entry_id}, {"$set": update_data})
    
    updated = await db.entries.find_one({"entry_id": entry_id}, {"_id": 0})
    if isinstance(updated.get("created_at"), str):
        updated["created_at"] = datetime.fromisoformat(updated["created_at"])
    if isinstance(updated.get("updated_at"), str):
        updated["updated_at"] = datetime.fromisoformat(updated["updated_at"])
    
    return updated

@api_router.delete("/entries/{entry_id}")
async def delete_entry(entry_id: str, request: Request):
    """Delete entry - Admin only"""
    await get_admin_user(request)
    
    entry = await db.entries.find_one({"entry_id": entry_id}, {"_id": 0})
    if not entry:
        raise HTTPException(status_code=404, detail="Registro no encontrado")
    
    await db.entries.delete_one({"entry_id": entry_id})
    
    return {"message": "Registro eliminado"}

# ============== CATEGORIES ==============

@api_router.get("/categories")
async def get_categories():
    """Get all categories with counts"""
    categories_with_counts = []
    
    for cat_id, cat_info in CATEGORY_INFO.items():
        count = await db.entries.count_documents({"category": cat_id})
        categories_with_counts.append({
            "id": cat_id,
            "name": cat_info["name"],
            "description": cat_info["description"],
            "count": count
        })
    
    return {"categories": categories_with_counts}

@api_router.get("/tags")
async def get_tags():
    """Get available tags"""
    return {
        "tags": [
            {"id": "real", "name": "Real", "description": "Eventos documentados o verificables"},
            {"id": "creencia", "name": "Creencia", "description": "Tradiciones y creencias populares"},
            {"id": "ficcion", "name": "Ficción", "description": "Relatos de ficción"}
        ]
    }

# ============== STATS ==============

@api_router.get("/stats")
async def get_stats():
    """Get archive statistics"""
    total_entries = await db.entries.count_documents({})
    
    categories_count = {}
    for cat_id in VALID_CATEGORIES:
        categories_count[cat_id] = await db.entries.count_documents({"category": cat_id})
    
    tags_count = {}
    for tag in VALID_TAGS:
        tags_count[tag] = await db.entries.count_documents({"tag": tag})
    
    return {
        "total_entries": total_entries,
        "categories": categories_count,
        "tags": tags_count
    }

# ============== IMAGE UPLOAD ==============

@api_router.post("/upload")
async def upload_image(file: UploadFile = File(...), request: Request = None):
    """Upload image - Admin only"""
    await get_admin_user(request)
    
    if not file.content_type.startswith("image/"):
        raise HTTPException(status_code=400, detail="Solo se permiten imágenes")
    
    contents = await file.read()
    if len(contents) > 5 * 1024 * 1024:
        raise HTTPException(status_code=400, detail="Archivo muy grande (máx 5MB)")
    
    base64_data = base64.b64encode(contents).decode('utf-8')
    data_url = f"data:{file.content_type};base64,{base64_data}"
    
    return {"url": data_url}

# Include the router
app.include_router(api_router)

app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=os.environ.get('CORS_ORIGINS', '*').split(','),
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.on_event("shutdown")
async def shutdown_db_client():
    client.close()
