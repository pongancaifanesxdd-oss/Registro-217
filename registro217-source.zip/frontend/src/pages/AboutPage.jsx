import Navbar from "../components/Navbar";
import { FileText, Eye, AlertTriangle, Archive } from "lucide-react";

const AboutPage = () => {
  return (
    <div className="min-h-screen bg-[#050505]">
      <Navbar />

      <div className="pt-24 pb-16">
        <div className="max-w-3xl mx-auto px-6">
          {/* Header */}
          <div className="mb-16">
            <div className="inline-flex items-center gap-2 mb-6 border border-primary/30 px-3 py-1">
              <Archive size={14} className="text-primary" />
              <span className="font-mono text-xs text-primary tracking-widest">INFORMACIÓN DEL ARCHIVO</span>
            </div>
            
            <h1 className="font-display text-4xl md:text-5xl text-[#e5e5e5] mb-6">
              Sobre el Archivo
            </h1>
            
            <p className="font-mono text-sm text-[#525252] border-l-2 border-primary/30 pl-4">
              REGISTRO 217 — ARCHIVOS CLASIFICADOS DE LO INEXPLICABLE
            </p>
          </div>

          {/* Content */}
          <div className="space-y-12">
            {/* Purpose */}
            <section>
              <h2 className="font-display text-2xl text-[#e5e5e5] mb-4 flex items-center gap-3">
                <FileText size={20} className="text-primary" />
                Propósito
              </h2>
              <div className="font-body text-[#a3a3a3] leading-relaxed space-y-4 pl-8">
                <p>
                  Registro 217 es un repositorio de lo prohibido, dedicado a documentar y preservar 
                  conocimiento sobre lo inexplicable, lo misterioso y lo que escapa a la 
                  comprensión convencional.
                </p>
                <p>
                  Este repositorio reúne una colección diversa de registros que abarcan desde 
                  creencias ancestrales y leyendas urbanas hasta fenómenos inexplicables, 
                  teorías alternativas y prácticas esotéricas de diversas culturas.
                </p>
                <p>
                  El objetivo es preservar este conocimiento de forma organizada y accesible, 
                  permitiendo a los interesados explorar estos temas con un criterio informado.
                </p>
              </div>
            </section>

            {/* Categories */}
            <section>
              <h2 className="font-display text-2xl text-[#e5e5e5] mb-4 flex items-center gap-3">
                <Archive size={20} className="text-primary" />
                Categorías del Archivo
              </h2>
              <div className="pl-8 grid grid-cols-1 md:grid-cols-2 gap-4">
                {[
                  { name: "Creencias", desc: "Supersticiones y creencias populares" },
                  { name: "Leyendas Urbanas", desc: "Historias transmitidas oralmente" },
                  { name: "Creepypasta", desc: "Relatos de terror de internet" },
                  { name: "Lost Media", desc: "Contenido perdido o difícil de encontrar" },
                  { name: "Teorías Conspirativas", desc: "Teorías alternativas" },
                  { name: "Mitos", desc: "Relatos de culturas ancestrales" },
                  { name: "Historias Reales", desc: "Eventos documentados" },
                  { name: "Fantasía", desc: "Ficción y mundos imaginarios" },
                  { name: "Misterios", desc: "Casos sin resolver" },
                  { name: "Rituales y Amarres", desc: "Prácticas rituales" },
                  { name: "Magia y Hechizos", desc: "Tradiciones esotéricas" },
                  { name: "Prácticas Mentales", desc: "Espiritualismo y chamanismo" },
                ].map((cat, i) => (
                  <div key={i} className="border border-[#1a1a1a] p-3">
                    <h3 className="font-ui text-sm text-[#e5e5e5]">{cat.name}</h3>
                    <p className="font-mono text-[10px] text-[#525252]">{cat.desc}</p>
                  </div>
                ))}
              </div>
            </section>

            {/* Classification System */}
            <section>
              <h2 className="font-display text-2xl text-[#e5e5e5] mb-4 flex items-center gap-3">
                <Eye size={20} className="text-primary" />
                Sistema de Clasificación
              </h2>
              <div className="pl-8 space-y-4">
                <p className="font-body text-[#a3a3a3]">
                  Cada registro está etiquetado según su naturaleza:
                </p>
                <div className="space-y-3">
                  <div className="flex items-start gap-3 p-4 border border-green-800/30 bg-green-900/10">
                    <span className="font-mono text-xs px-2 py-0.5 bg-green-900/30 text-green-400 border border-green-800/50">
                      REAL
                    </span>
                    <p className="font-mono text-sm text-[#a3a3a3]">
                      Eventos documentados, casos verificables o fenómenos con evidencia tangible.
                    </p>
                  </div>
                  <div className="flex items-start gap-3 p-4 border border-amber-800/30 bg-amber-900/10">
                    <span className="font-mono text-xs px-2 py-0.5 bg-amber-900/30 text-amber-400 border border-amber-800/50">
                      CREENCIA
                    </span>
                    <p className="font-mono text-sm text-[#a3a3a3]">
                      Tradiciones populares, supersticiones y creencias culturales sin verificación empírica.
                    </p>
                  </div>
                  <div className="flex items-start gap-3 p-4 border border-blue-800/30 bg-blue-900/10">
                    <span className="font-mono text-xs px-2 py-0.5 bg-blue-900/30 text-blue-400 border border-blue-800/50">
                      FICCIÓN
                    </span>
                    <p className="font-mono text-sm text-[#a3a3a3]">
                      Obras creativas, relatos inventados y narrativas de entretenimiento.
                    </p>
                  </div>
                </div>
              </div>
            </section>

            {/* Disclaimer */}
            <section className="border border-amber-800/30 bg-amber-900/10 p-6">
              <h2 className="font-display text-xl text-amber-400 mb-4 flex items-center gap-3">
                <AlertTriangle size={20} />
                Aviso Importante
              </h2>
              <div className="font-body text-sm text-amber-200/80 space-y-3">
                <p>
                  Los contenidos de este archivo son de naturaleza diversa y no todos representan 
                  hechos verificados. El lector debe ejercer su propio juicio crítico al interpretar 
                  la información presentada.
                </p>
                <p>
                  Las prácticas descritas en algunas categorías (rituales, magia, etc.) son documentadas 
                  con fines informativos y culturales. No se recomienda ni se promueve la realización 
                  de ninguna práctica que pueda resultar perjudicial.
                </p>
                <p>
                  Este archivo no pretende promover ninguna creencia particular ni validar la veracidad 
                  de teorías conspirativas o fenómenos paranormales. Su propósito es puramente 
                  documental y de preservación cultural.
                </p>
              </div>
            </section>

            {/* Keeper */}
            <section>
              <h2 className="font-display text-2xl text-[#e5e5e5] mb-4">
                El Guardián
              </h2>
              <div className="pl-8">
                <p className="font-body text-[#a3a3a3]">
                  Este archivo es resguardado por un único guardián que recopila, verifica 
                  y cataloga cada registro desde las sombras. No es una plataforma abierta 
                  — solo lo digno de ser preservado encuentra su lugar aquí.
                </p>
              </div>
            </section>
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="py-8 border-t border-[#1a1a1a]">
        <div className="max-w-3xl mx-auto px-6 text-center">
          <p className="font-mono text-xs text-[#333]">
            REGISTRO 217 — ARCHIVOS CLASIFICADOS DE LO INEXPLICABLE
          </p>
        </div>
      </footer>
    </div>
  );
};

export default AboutPage;
