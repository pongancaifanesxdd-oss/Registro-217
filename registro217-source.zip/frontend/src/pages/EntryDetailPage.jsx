import { useState, useEffect } from "react";
import { useParams, Link, useNavigate } from "react-router-dom";
import axios from "axios";
import { API, useAdmin } from "../App";
import Navbar from "../components/Navbar";
import { Button } from "../components/ui/button";
import { ChevronLeft, Clock, FileText, Edit2, Trash2, AlertTriangle } from "lucide-react";
import { format } from "date-fns";
import { es } from "date-fns/locale";
import { toast } from "sonner";

const categoryLabels = {
  "creencias": "Creencias",
  "leyendas-urbanas": "Leyendas Urbanas",
  "creepypasta": "Creepypasta",
  "lost-media": "Lost Media",
  "teorias-conspirativas": "Teorías Conspirativas",
  "mitos": "Mitos",
  "historias-reales": "Historias Reales",
  "fantasia": "Fantasía",
  "misterios": "Misterios",
  "rituales-amarres": "Rituales y Amarres",
  "magia-hechizos": "Magia y Hechizos",
  "practicas-mentales": "Prácticas Mentales",
};

const tagInfo = {
  "real": { name: "Real", color: "bg-green-900/30 text-green-400 border-green-800/50", description: "Este registro documenta eventos reales o verificables" },
  "creencia": { name: "Creencia", color: "bg-amber-900/30 text-amber-400 border-amber-800/50", description: "Este registro representa una creencia o tradición popular" },
  "ficcion": { name: "Ficción", color: "bg-blue-900/30 text-blue-400 border-blue-800/50", description: "Este registro es una obra de ficción" },
};

const EntryDetailPage = () => {
  const { entryId } = useParams();
  const navigate = useNavigate();
  const { admin } = useAdmin();
  const [entry, setEntry] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchEntry();
  }, [entryId]);

  const fetchEntry = async () => {
    try {
      const response = await axios.get(`${API}/entries/${entryId}`);
      setEntry(response.data);
    } catch (error) {
      console.error("Error fetching entry:", error);
      toast.error("Registro no encontrado");
      navigate("/");
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async () => {
    if (!window.confirm("¿Eliminar este registro permanentemente?")) return;

    try {
      await axios.delete(`${API}/entries/${entryId}`, { withCredentials: true });
      toast.success("Registro eliminado");
      navigate("/");
    } catch (error) {
      toast.error("Error al eliminar");
    }
  };

  const formatDate = (dateString) => {
    try {
      return format(new Date(dateString), "d 'de' MMMM, yyyy", { locale: es });
    } catch {
      return "";
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-[#050505]">
        <Navbar />
        <div className="pt-32 max-w-3xl mx-auto px-6">
          <div className="skeleton h-8 w-32 mb-4" />
          <div className="skeleton h-12 w-full mb-6" />
          <div className="space-y-4">
            {[1, 2, 3, 4].map(i => (
              <div key={i} className="skeleton h-4 w-full" />
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (!entry) return null;

  const tag = tagInfo[entry.tag] || tagInfo.ficcion;

  return (
    <div className="min-h-screen bg-[#050505]">
      <Navbar />

      <article className="pt-24 pb-16">
        {/* Header */}
        <div className="max-w-3xl mx-auto px-6">
          <Link 
            to={`/categoria/${entry.category}`}
            className="inline-flex items-center gap-2 text-[#525252] hover:text-[#737373] mb-8 transition-colors"
          >
            <ChevronLeft size={16} />
            <span className="font-mono text-sm">{categoryLabels[entry.category] || entry.category}</span>
          </Link>

          {/* Classification */}
          <div className="flex items-center gap-3 mb-6">
            <span className="font-mono text-[10px] text-[#525252] uppercase tracking-widest">
              REG-{entry.entry_id.slice(-6).toUpperCase()}
            </span>
            <span className={`font-mono text-[10px] px-2 py-0.5 border ${tag.color}`}>
              {tag.name}
            </span>
          </div>

          {/* Title */}
          <h1 
            className="font-display text-3xl md:text-5xl text-[#e5e5e5] tracking-tight mb-6 leading-tight"
            data-testid="entry-title"
          >
            {entry.title}
          </h1>

          {/* Meta */}
          <div className="flex items-center justify-between flex-wrap gap-4 pb-6 mb-8 border-b border-[#1a1a1a]">
            <div className="flex items-center gap-4 text-[#525252]">
              <div className="flex items-center gap-1">
                <Clock size={14} />
                <span className="font-mono text-xs">{formatDate(entry.created_at)}</span>
              </div>
              <div className="flex items-center gap-1">
                <FileText size={14} />
                <span className="font-mono text-xs">{categoryLabels[entry.category]}</span>
              </div>
            </div>

            {/* Admin Actions */}
            {admin && (
              <div className="flex items-center gap-2">
                <Link to={`/admin/editar/${entry.entry_id}`}>
                  <Button variant="ghost" size="sm" className="text-[#525252] hover:text-[#e5e5e5] h-8">
                    <Edit2 size={14} className="mr-1" />
                    Editar
                  </Button>
                </Link>
                <Button 
                  variant="ghost" 
                  size="sm" 
                  className="text-[#525252] hover:text-red-500 h-8"
                  onClick={handleDelete}
                  data-testid="delete-entry-btn"
                >
                  <Trash2 size={14} className="mr-1" />
                  Eliminar
                </Button>
              </div>
            )}
          </div>
        </div>

        {/* Tag Warning */}
        <div className="max-w-3xl mx-auto px-6 mb-8">
          <div className={`flex items-start gap-3 p-4 border ${tag.color}`}>
            <AlertTriangle size={16} className="flex-shrink-0 mt-0.5" />
            <p className="font-mono text-xs">
              {tag.description}
            </p>
          </div>
        </div>

        {/* Image */}
        {entry.image_url && (
          <div className="max-w-4xl mx-auto mb-10">
            <img 
              src={entry.image_url} 
              alt={entry.title}
              className="w-full max-h-[500px] object-cover"
            />
          </div>
        )}

        {/* Content */}
        <div className="max-w-3xl mx-auto px-6">
          <div 
            className="prose-mystery font-body text-[#d4d4d4] text-lg leading-loose"
            data-testid="entry-content"
          >
            {entry.content.split('\n').map((paragraph, index) => (
              paragraph.trim() && <p key={index} className="mb-6">{paragraph}</p>
            ))}
          </div>
        </div>

        {/* Footer */}
        <div className="max-w-3xl mx-auto px-6 mt-16 pt-8 border-t border-[#1a1a1a]">
          <div className="flex items-center justify-between">
            <Link 
              to={`/categoria/${entry.category}`}
              className="font-mono text-xs text-[#525252] hover:text-primary transition-colors"
            >
              ← Más en {categoryLabels[entry.category]}
            </Link>
            <span className="font-mono text-[10px] text-[#333]">
              Última actualización: {formatDate(entry.updated_at)}
            </span>
          </div>
        </div>
      </article>
    </div>
  );
};

export default EntryDetailPage;
