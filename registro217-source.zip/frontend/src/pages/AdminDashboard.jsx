import { useState, useEffect } from "react";
import { useNavigate, Link } from "react-router-dom";
import axios from "axios";
import { API, useAdmin } from "../App";
import { toast } from "sonner";
import Navbar from "../components/Navbar";
import { Button } from "../components/ui/button";
import { Plus, FileText, Edit2, Trash2, LogOut, Search } from "lucide-react";
import { Input } from "../components/ui/input";
import { format } from "date-fns";
import { es } from "date-fns/locale";

const categoryLabels = {
  "creencias": "Creencias",
  "leyendas-urbanas": "Leyendas Urbanas",
  "creepypasta": "Creepypasta",
  "lost-media": "Lost Media",
  "teorias-conspirativas": "Teorías Conspirativas",
  "mitos": "Mitos",
  "historias-reales": "Historias Reales",
  "fantasia": "Fantasía",
  "misterios": "Misterios",
  "rituales-amarres": "Rituales y Amarres",
  "magia-hechizos": "Magia y Hechizos",
  "practicas-mentales": "Prácticas Mentales",
};

const tagColors = {
  "real": "text-green-400",
  "creencia": "text-amber-400",
  "ficcion": "text-blue-400",
};

const AdminDashboard = () => {
  const navigate = useNavigate();
  const { admin, logout, loading: authLoading } = useAdmin();
  const [entries, setEntries] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [stats, setStats] = useState(null);

  useEffect(() => {
    if (!authLoading && !admin) {
      navigate("/admin");
    }
  }, [admin, authLoading, navigate]);

  useEffect(() => {
    if (admin) {
      fetchEntries();
      fetchStats();
    }
  }, [admin]);

  const fetchEntries = async () => {
    try {
      const response = await axios.get(`${API}/entries?limit=100`, { withCredentials: true });
      setEntries(response.data.entries || []);
    } catch (error) {
      console.error("Error fetching entries:", error);
    } finally {
      setLoading(false);
    }
  };

  const fetchStats = async () => {
    try {
      const response = await axios.get(`${API}/stats`);
      setStats(response.data);
    } catch (error) {
      console.error("Error fetching stats:", error);
    }
  };

  const handleDelete = async (entryId) => {
    if (!window.confirm("¿Eliminar este registro permanentemente?")) return;

    try {
      await axios.delete(`${API}/entries/${entryId}`, { withCredentials: true });
      setEntries(entries.filter(e => e.entry_id !== entryId));
      toast.success("Registro eliminado");
    } catch (error) {
      toast.error("Error al eliminar");
    }
  };

  const handleLogout = async () => {
    await logout();
    navigate("/");
  };

  const formatDate = (dateString) => {
    try {
      return format(new Date(dateString), "d MMM yyyy", { locale: es });
    } catch {
      return "";
    }
  };

  const filteredEntries = entries.filter(entry => 
    entry.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    entry.category.toLowerCase().includes(searchQuery.toLowerCase())
  );

  if (authLoading) {
    return (
      <div className="min-h-screen bg-[#050505] flex items-center justify-center">
        <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (!admin) return null;

  return (
    <div className="min-h-screen bg-[#050505]">
      <Navbar />

      <div className="pt-24 pb-16 max-w-6xl mx-auto px-6">
        {/* Header */}
        <div className="flex items-start justify-between mb-8">
          <div>
            <h1 className="font-display text-3xl text-[#e5e5e5] mb-2">Panel de Administración</h1>
            <p className="font-mono text-xs text-[#525252]">
              Bienvenido, {admin.name}
            </p>
          </div>
          <div className="flex items-center gap-3">
            <Link to="/admin/nuevo">
              <Button className="bg-primary hover:bg-primary/90 font-mono text-sm">
                <Plus size={16} className="mr-2" />
                Nuevo Registro
              </Button>
            </Link>
            <Button 
              variant="outline" 
              className="border-[#1a1a1a] font-mono text-sm"
              onClick={handleLogout}
            >
              <LogOut size={16} className="mr-2" />
              Salir
            </Button>
          </div>
        </div>

        {/* Stats */}
        {stats && (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
            <div className="bg-[#0a0a0a] border border-[#1a1a1a] p-4">
              <p className="font-mono text-2xl text-primary">{stats.total_entries}</p>
              <p className="font-mono text-[10px] text-[#525252] uppercase">Total Registros</p>
            </div>
            <div className="bg-[#0a0a0a] border border-[#1a1a1a] p-4">
              <p className="font-mono text-2xl text-green-400">{stats.tags?.real || 0}</p>
              <p className="font-mono text-[10px] text-[#525252] uppercase">Reales</p>
            </div>
            <div className="bg-[#0a0a0a] border border-[#1a1a1a] p-4">
              <p className="font-mono text-2xl text-amber-400">{stats.tags?.creencia || 0}</p>
              <p className="font-mono text-[10px] text-[#525252] uppercase">Creencias</p>
            </div>
            <div className="bg-[#0a0a0a] border border-[#1a1a1a] p-4">
              <p className="font-mono text-2xl text-blue-400">{stats.tags?.ficcion || 0}</p>
              <p className="font-mono text-[10px] text-[#525252] uppercase">Ficción</p>
            </div>
          </div>
        )}

        {/* Search */}
        <div className="mb-6">
          <div className="relative w-full md:w-64">
            <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#525252]" />
            <Input
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="bg-[#0a0a0a] border-[#1a1a1a] pl-9 font-mono text-sm"
              placeholder="Buscar registros..."
            />
          </div>
        </div>

        {/* Entries Table */}
        <div className="bg-[#0a0a0a] border border-[#1a1a1a]">
          <div className="grid grid-cols-12 gap-4 p-4 border-b border-[#1a1a1a] font-mono text-[10px] text-[#525252] uppercase tracking-wider">
            <div className="col-span-5">Título</div>
            <div className="col-span-2">Categoría</div>
            <div className="col-span-1">Tag</div>
            <div className="col-span-2">Fecha</div>
            <div className="col-span-2">Acciones</div>
          </div>

          {loading ? (
            <div className="p-8 text-center">
              <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin mx-auto" />
            </div>
          ) : filteredEntries.length === 0 ? (
            <div className="p-8 text-center">
              <FileText size={32} className="mx-auto mb-4 text-[#333]" />
              <p className="font-mono text-sm text-[#525252]">No hay registros</p>
              <Link to="/admin/nuevo" className="font-mono text-xs text-primary hover:underline mt-2 inline-block">
                Crear primer registro
              </Link>
            </div>
          ) : (
            filteredEntries.map((entry) => (
              <div 
                key={entry.entry_id}
                className="grid grid-cols-12 gap-4 p-4 border-b border-[#1a1a1a]/50 items-center hover:bg-[#0f0f0f] transition-colors"
              >
                <div className="col-span-5">
                  <Link 
                    to={`/registro/${entry.entry_id}`}
                    className="font-body text-sm text-[#e5e5e5] hover:text-primary transition-colors line-clamp-1"
                  >
                    {entry.title}
                  </Link>
                  <p className="font-mono text-[10px] text-[#525252]">
                    REG-{entry.entry_id.slice(-6).toUpperCase()}
                  </p>
                </div>
                <div className="col-span-2">
                  <span className="font-mono text-xs text-[#737373]">
                    {categoryLabels[entry.category] || entry.category}
                  </span>
                </div>
                <div className="col-span-1">
                  <span className={`font-mono text-xs capitalize ${tagColors[entry.tag] || 'text-[#737373]'}`}>
                    {entry.tag}
                  </span>
                </div>
                <div className="col-span-2">
                  <span className="font-mono text-xs text-[#525252]">
                    {formatDate(entry.created_at)}
                  </span>
                </div>
                <div className="col-span-2 flex gap-2">
                  <Link to={`/admin/editar/${entry.entry_id}`}>
                    <Button variant="ghost" size="sm" className="h-8 w-8 p-0 text-[#525252] hover:text-[#e5e5e5]">
                      <Edit2 size={14} />
                    </Button>
                  </Link>
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    className="h-8 w-8 p-0 text-[#525252] hover:text-red-500"
                    onClick={() => handleDelete(entry.entry_id)}
                  >
                    <Trash2 size={14} />
                  </Button>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;
