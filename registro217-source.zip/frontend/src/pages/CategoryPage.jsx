import { useState, useEffect } from "react";
import { useParams, Link, useSearchParams } from "react-router-dom";
import axios from "axios";
import { API } from "../App";
import Navbar from "../components/Navbar";
import EntryCard from "../components/EntryCard";
import { Input } from "../components/ui/input";
import { Button } from "../components/ui/button";
import { Search, ChevronLeft, Filter } from "lucide-react";

const categoryData = {
  "all": { name: "Todos los Registros", description: "Explorar todo el archivo" },
  "creencias": { name: "Creencias", description: "Creencias populares y supersticiones" },
  "leyendas-urbanas": { name: "Leyendas Urbanas", description: "Historias transmitidas de generación en generación" },
  "creepypasta": { name: "Creepypasta", description: "Relatos de terror nacidos en internet" },
  "lost-media": { name: "Lost Media", description: "Contenido perdido o difícil de encontrar" },
  "teorias-conspirativas": { name: "Teorías Conspirativas", description: "Teorías alternativas sobre eventos y fenómenos" },
  "mitos": { name: "Mitos", description: "Relatos tradicionales de culturas ancestrales" },
  "historias-reales": { name: "Historias Reales", description: "Eventos documentados y verificables" },
  "fantasia": { name: "Fantasía", description: "Relatos de ficción y mundos imaginarios" },
  "misterios": { name: "Misterios", description: "Casos sin resolver y enigmas" },
  "rituales-amarres": { name: "Rituales y Amarres", description: "Prácticas rituales y tradiciones" },
  "magia-hechizos": { name: "Magia y Hechizos", description: "Tradiciones mágicas y esotéricas" },
  "practicas-mentales": { name: "Prácticas Mentales", description: "Espiritualismo, misticismo y chamanismo" },
};

const CategoryPage = () => {
  const { categoryId } = useParams();
  const [searchParams] = useSearchParams();
  const initialSearch = searchParams.get('search') || '';
  
  const [entries, setEntries] = useState([]);
  const [loading, setLoading] = useState(true);
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [searchQuery, setSearchQuery] = useState(initialSearch);
  const [activeTag, setActiveTag] = useState("");

  const category = categoryData[categoryId] || categoryData["all"];

  useEffect(() => {
    fetchEntries();
  }, [categoryId, page, activeTag]);

  useEffect(() => {
    if (initialSearch) {
      handleSearch();
    }
  }, []);

  const fetchEntries = async () => {
    setLoading(true);
    try {
      let url = `${API}/entries?page=${page}&limit=12`;
      if (categoryId && categoryId !== "all") {
        url += `&category=${categoryId}`;
      }
      if (activeTag) {
        url += `&tag=${activeTag}`;
      }
      if (searchQuery) {
        url += `&search=${encodeURIComponent(searchQuery)}`;
      }
      
      const response = await axios.get(url);
      setEntries(response.data.entries || []);
      setTotalPages(response.data.pages || 1);
    } catch (error) {
      console.error("Error fetching entries:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleSearch = (e) => {
    if (e) e.preventDefault();
    setPage(1);
    fetchEntries();
  };

  const tags = [
    { id: "", name: "Todos" },
    { id: "real", name: "Real" },
    { id: "creencia", name: "Creencia" },
    { id: "ficcion", name: "Ficción" },
  ];

  return (
    <div className="min-h-screen bg-[#050505]">
      <Navbar />

      <div className="pt-24 pb-16">
        {/* Header */}
        <div className="max-w-6xl mx-auto px-6 mb-12">
          <Link 
            to="/" 
            className="inline-flex items-center gap-2 text-[#525252] hover:text-[#737373] mb-6 transition-colors"
          >
            <ChevronLeft size={16} />
            <span className="font-mono text-sm">Volver al índice</span>
          </Link>

          <div className="border-l-2 border-primary pl-6">
            <h1 
              className="font-display text-3xl md:text-4xl text-[#e5e5e5] mb-2"
              data-testid="category-title"
            >
              {category.name}
            </h1>
            <p className="font-mono text-sm text-[#525252]">
              {category.description}
            </p>
          </div>
        </div>

        {/* Filters */}
        <div className="max-w-6xl mx-auto px-6 mb-8">
          <div className="flex flex-col md:flex-row gap-4 items-start md:items-center justify-between">
            {/* Search */}
            <form onSubmit={handleSearch} className="flex gap-2 w-full md:w-auto">
              <div className="relative flex-1 md:w-64">
                <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#525252]" />
                <Input
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="bg-[#0a0a0a] border-[#1a1a1a] pl-9 font-mono text-sm h-9"
                  placeholder="Buscar..."
                  data-testid="category-search"
                />
              </div>
              <Button type="submit" variant="outline" size="sm" className="border-[#1a1a1a] h-9">
                <Search size={14} />
              </Button>
            </form>

            {/* Tag Filters */}
            <div className="flex items-center gap-2">
              <Filter size={14} className="text-[#525252]" />
              <div className="flex gap-1">
                {tags.map((tag) => (
                  <button
                    key={tag.id}
                    onClick={() => { setActiveTag(tag.id); setPage(1); }}
                    className={`font-mono text-xs px-3 py-1.5 border transition-colors ${
                      activeTag === tag.id
                        ? "border-primary text-primary bg-primary/10"
                        : "border-[#1a1a1a] text-[#525252] hover:text-[#737373] hover:border-[#333]"
                    }`}
                  >
                    {tag.name}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Entries Grid */}
        <div className="max-w-6xl mx-auto px-6">
          {loading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[1, 2, 3, 4, 5, 6].map(i => (
                <div key={i} className="skeleton h-48" />
              ))}
            </div>
          ) : entries.length === 0 ? (
            <div className="text-center py-16 border border-[#1a1a1a]">
              <p className="font-mono text-sm text-[#525252]">
                No se encontraron registros
              </p>
            </div>
          ) : (
            <>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {entries.map((entry, index) => (
                  <div 
                    key={entry.entry_id}
                    className="animate-fade-in-up"
                    style={{ animationDelay: `${index * 50}ms` }}
                  >
                    <EntryCard entry={entry} />
                  </div>
                ))}
              </div>

              {/* Pagination */}
              {totalPages > 1 && (
                <div className="flex justify-center gap-1 mt-12">
                  {Array.from({ length: totalPages }, (_, i) => i + 1).map(p => (
                    <button
                      key={p}
                      onClick={() => setPage(p)}
                      className={`w-8 h-8 font-mono text-xs transition-colors ${
                        p === page 
                          ? "bg-primary text-white" 
                          : "bg-[#0a0a0a] text-[#525252] hover:text-[#737373] border border-[#1a1a1a]"
                      }`}
                    >
                      {p}
                    </button>
                  ))}
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
};

export default CategoryPage;
