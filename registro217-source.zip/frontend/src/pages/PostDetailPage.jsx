import { useState, useEffect } from "react";
import { useParams, Link, useNavigate } from "react-router-dom";
import axios from "axios";
import { API, useAuth } from "../App";
import { toast } from "sonner";
import Navbar from "../components/Navbar";
import CommentSection from "../components/CommentSection";
import { Button } from "../components/ui/button";
import { Heart, MessageCircle, User, ChevronLeft, Edit2, Trash2, Clock, Share2 } from "lucide-react";
import { formatDistanceToNow, format } from "date-fns";
import { es } from "date-fns/locale";

const categoryLabels = {
  "creencias": "Creencias",
  "leyendas-urbanas": "Leyendas Urbanas",
  "creepypasta": "Creepypasta",
  "lost-media": "Lost Media",
};

const PostDetailPage = () => {
  const { postId } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [post, setPost] = useState(null);
  const [loading, setLoading] = useState(true);
  const [liked, setLiked] = useState(false);
  const [likesCount, setLikesCount] = useState(0);

  useEffect(() => {
    fetchPost();
    if (user) {
      checkLikeStatus();
    }
  }, [postId, user]);

  const fetchPost = async () => {
    try {
      const response = await axios.get(`${API}/posts/${postId}`);
      setPost(response.data);
      setLikesCount(response.data.likes_count || 0);
    } catch (error) {
      console.error("Error fetching post:", error);
      toast.error("Historia no encontrada");
      navigate("/");
    } finally {
      setLoading(false);
    }
  };

  const checkLikeStatus = async () => {
    try {
      const response = await axios.get(`${API}/posts/${postId}/like-status`, {
        withCredentials: true
      });
      setLiked(response.data.liked);
    } catch (error) {
      console.error("Error checking like status:", error);
    }
  };

  const handleLike = async () => {
    if (!user) {
      toast.error("Inicia sesión para dar like");
      return;
    }

    try {
      const response = await axios.post(
        `${API}/posts/${postId}/like`,
        {},
        { withCredentials: true }
      );
      setLiked(response.data.liked);
      setLikesCount(response.data.likes_count);
    } catch (error) {
      toast.error("Error al procesar like");
    }
  };

  const handleDelete = async () => {
    if (!window.confirm("¿Estás seguro de eliminar esta historia?")) return;

    try {
      await axios.delete(`${API}/posts/${postId}`, { withCredentials: true });
      toast.success("Historia eliminada");
      navigate("/");
    } catch (error) {
      toast.error("Error al eliminar");
    }
  };

  const handleShare = async () => {
    try {
      await navigator.clipboard.writeText(window.location.href);
      toast.success("Enlace copiado");
    } catch {
      toast.error("Error al copiar enlace");
    }
  };

  const formatDate = (dateString) => {
    try {
      const date = new Date(dateString);
      return format(date, "d 'de' MMMM, yyyy", { locale: es });
    } catch {
      return "";
    }
  };

  const formatRelativeDate = (dateString) => {
    try {
      return formatDistanceToNow(new Date(dateString), { addSuffix: true, locale: es });
    } catch {
      return "";
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-[#050505]">
        <Navbar />
        <div className="pt-32 max-w-2xl mx-auto px-6">
          <div className="skeleton h-8 w-32 mb-4" />
          <div className="skeleton h-12 w-full mb-6" />
          <div className="skeleton h-4 w-48 mb-8" />
          <div className="space-y-4">
            {[1, 2, 3, 4].map(i => (
              <div key={i} className="skeleton h-4 w-full" />
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (!post) return null;

  const isAuthor = user && user.user_id === post.author_id;
  const isAdmin = user && (user.role === "admin" || user.role === "moderator");

  return (
    <div className="min-h-screen bg-[#050505]">
      <Navbar />

      <article className="pt-24 pb-16">
        {/* Header */}
        <div className="max-w-2xl mx-auto px-6 md:px-12">
          <Link 
            to={`/category/${post.category}`}
            className="inline-flex items-center gap-2 text-[#a3a3a3] hover:text-[#e5e5e5] mb-8 transition-colors"
          >
            <ChevronLeft size={18} />
            <span className="font-ui text-sm">{categoryLabels[post.category] || post.category}</span>
          </Link>

          {/* Category & Anonymous Badge */}
          <div className="flex items-center gap-3 mb-4">
            <span className="font-ui text-xs text-primary uppercase tracking-widest">
              {categoryLabels[post.category] || post.category}
            </span>
            {post.is_anonymous && (
              <span className="badge-anonymous font-ui uppercase tracking-wider">
                Anónimo
              </span>
            )}
          </div>

          {/* Title */}
          <h1 
            className="font-display text-3xl md:text-5xl text-[#e5e5e5] tracking-tight mb-6"
            data-testid="post-title"
          >
            {post.title}
          </h1>

          {/* Author & Meta */}
          <div className="flex items-center justify-between flex-wrap gap-4 pb-8 border-b border-[#262626]/30">
            <div className="flex items-center gap-3">
              {post.author_picture && !post.is_anonymous ? (
                <img 
                  src={post.author_picture} 
                  alt={post.author_name}
                  className="w-10 h-10 rounded-full object-cover"
                />
              ) : (
                <div className="w-10 h-10 rounded-full bg-[#171717] flex items-center justify-center">
                  <User size={18} className="text-[#737373]" />
                </div>
              )}
              <div>
                <p className="font-ui text-sm text-[#e5e5e5]">
                  {post.is_anonymous ? (post.pseudonym || "Anónimo") : post.author_name}
                </p>
                <p className="font-ui text-xs text-[#737373] flex items-center gap-1">
                  <Clock size={12} />
                  {formatDate(post.created_at)}
                </p>
              </div>
            </div>

            {/* Actions */}
            <div className="flex items-center gap-2">
              {(isAuthor || isAdmin) && (
                <>
                  <Link to={`/edit/${post.post_id}`}>
                    <Button variant="ghost" size="sm" className="text-[#a3a3a3] hover:text-[#e5e5e5]">
                      <Edit2 size={16} />
                    </Button>
                  </Link>
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    className="text-[#a3a3a3] hover:text-red-500"
                    onClick={handleDelete}
                    data-testid="delete-post-btn"
                  >
                    <Trash2 size={16} />
                  </Button>
                </>
              )}
              <Button 
                variant="ghost" 
                size="sm" 
                className="text-[#a3a3a3] hover:text-[#e5e5e5]"
                onClick={handleShare}
              >
                <Share2 size={16} />
              </Button>
            </div>
          </div>
        </div>

        {/* Post Image */}
        {post.image_url && (
          <div className="max-w-4xl mx-auto my-8">
            <img 
              src={post.image_url} 
              alt={post.title}
              className="w-full max-h-[500px] object-cover"
            />
          </div>
        )}

        {/* Content */}
        <div className="max-w-2xl mx-auto px-6 md:px-12 py-8">
          <div 
            className="post-content prose-mystery text-[#d4d4d4]"
            data-testid="post-content"
          >
            {post.content.split('\n').map((paragraph, index) => (
              paragraph.trim() && <p key={index}>{paragraph}</p>
            ))}
          </div>
        </div>

        {/* Engagement Bar */}
        <div className="max-w-2xl mx-auto px-6 md:px-12 py-6 border-t border-b border-[#262626]/30">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-6">
              <button 
                onClick={handleLike}
                className={`like-btn flex items-center gap-2 transition-colors ${
                  liked ? "text-primary liked" : "text-[#a3a3a3] hover:text-primary"
                }`}
                data-testid="like-btn"
              >
                <Heart size={20} fill={liked ? "currentColor" : "none"} />
                <span className="font-ui text-sm">{likesCount}</span>
              </button>
              <div className="flex items-center gap-2 text-[#a3a3a3]">
                <MessageCircle size={20} />
                <span className="font-ui text-sm">{post.comments_count || 0}</span>
              </div>
            </div>
            <span className="font-ui text-xs text-[#737373]">
              {formatRelativeDate(post.created_at)}
            </span>
          </div>
        </div>

        {/* Comments Section */}
        <div className="max-w-2xl mx-auto px-6 md:px-12">
          <CommentSection postId={postId} />
        </div>
      </article>
    </div>
  );
};

export default PostDetailPage;
