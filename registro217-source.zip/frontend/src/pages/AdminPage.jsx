import { useState, useEffect } from "react";
import { useNavigate, Link } from "react-router-dom";
import axios from "axios";
import { API, useAuth } from "../App";
import { toast } from "sonner";
import Navbar from "../components/Navbar";
import { Button } from "../components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "../components/ui/select";
import { 
  BookOpen, 
  Users, 
  MessageCircle, 
  Eye, 
  EyeOff, 
  Trash2,
  Shield,
  ChevronLeft
} from "lucide-react";
import { format } from "date-fns";
import { es } from "date-fns/locale";

const AdminPage = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [posts, setPosts] = useState([]);
  const [users, setUsers] = useState([]);
  const [loadingPosts, setLoadingPosts] = useState(true);
  const [loadingUsers, setLoadingUsers] = useState(true);

  useEffect(() => {
    if (!user || (user.role !== "admin" && user.role !== "moderator")) {
      toast.error("Acceso no autorizado");
      navigate("/");
      return;
    }
    
    fetchPosts();
    fetchUsers();
  }, [user, navigate]);

  const fetchPosts = async () => {
    try {
      const response = await axios.get(`${API}/admin/posts`, { withCredentials: true });
      setPosts(response.data.posts || []);
    } catch (error) {
      console.error("Error fetching posts:", error);
    } finally {
      setLoadingPosts(false);
    }
  };

  const fetchUsers = async () => {
    try {
      const response = await axios.get(`${API}/admin/users`, { withCredentials: true });
      setUsers(response.data.users || []);
    } catch (error) {
      console.error("Error fetching users:", error);
    } finally {
      setLoadingUsers(false);
    }
  };

  const handleModeratePost = async (postId) => {
    try {
      const response = await axios.post(
        `${API}/admin/posts/${postId}/moderate`,
        {},
        { withCredentials: true }
      );
      setPosts(posts.map(p => 
        p.post_id === postId 
          ? { ...p, is_moderated: response.data.is_moderated }
          : p
      ));
      toast.success(response.data.is_moderated ? "Post ocultado" : "Post visible");
    } catch (error) {
      toast.error("Error al moderar");
    }
  };

  const handleDeletePost = async (postId) => {
    if (!window.confirm("¿Eliminar este post permanentemente?")) return;
    
    try {
      await axios.delete(`${API}/posts/${postId}`, { withCredentials: true });
      setPosts(posts.filter(p => p.post_id !== postId));
      toast.success("Post eliminado");
    } catch (error) {
      toast.error("Error al eliminar");
    }
  };

  const handleUpdateRole = async (userId, newRole) => {
    try {
      await axios.put(
        `${API}/admin/users/${userId}/role`,
        { role: newRole },
        { withCredentials: true }
      );
      setUsers(users.map(u => 
        u.user_id === userId ? { ...u, role: newRole } : u
      ));
      toast.success("Rol actualizado");
    } catch (error) {
      toast.error("Error al actualizar rol");
    }
  };

  const formatDate = (dateString) => {
    try {
      return format(new Date(dateString), "d MMM yyyy", { locale: es });
    } catch {
      return "";
    }
  };

  if (!user || (user.role !== "admin" && user.role !== "moderator")) {
    return null;
  }

  return (
    <div className="min-h-screen bg-[#050505]">
      <Navbar />

      <div className="pt-24 pb-16 max-w-6xl mx-auto px-6 md:px-12">
        <Link 
          to="/"
          className="inline-flex items-center gap-2 text-[#a3a3a3] hover:text-[#e5e5e5] mb-8 transition-colors"
        >
          <ChevronLeft size={18} />
          <span className="font-ui text-sm">Volver</span>
        </Link>

        <div className="flex items-center gap-3 mb-8">
          <Shield size={32} className="text-primary" />
          <div>
            <h1 className="font-display text-3xl text-[#e5e5e5]">Panel de Administración</h1>
            <p className="font-ui text-sm text-[#737373]">Gestiona el contenido y usuarios</p>
          </div>
        </div>

        <Tabs defaultValue="posts" className="w-full">
          <TabsList className="bg-[#0a0a0a] border border-[#262626]/30 p-1 mb-8">
            <TabsTrigger 
              value="posts" 
              className="data-[state=active]:bg-primary data-[state=active]:text-white font-ui text-sm"
            >
              <BookOpen size={16} className="mr-2" />
              Publicaciones ({posts.length})
            </TabsTrigger>
            <TabsTrigger 
              value="users"
              className="data-[state=active]:bg-primary data-[state=active]:text-white font-ui text-sm"
            >
              <Users size={16} className="mr-2" />
              Usuarios ({users.length})
            </TabsTrigger>
          </TabsList>

          {/* Posts Tab */}
          <TabsContent value="posts">
            {loadingPosts ? (
              <div className="space-y-2">
                {[1, 2, 3, 4, 5].map(i => (
                  <div key={i} className="skeleton h-16 w-full" />
                ))}
              </div>
            ) : posts.length === 0 ? (
              <p className="font-ui text-[#737373] text-center py-8">No hay publicaciones</p>
            ) : (
              <div className="bg-[#0a0a0a] border border-[#262626]/30">
                <div className="grid grid-cols-12 gap-4 p-4 border-b border-[#262626]/30 font-ui text-xs text-[#737373] uppercase tracking-wider">
                  <div className="col-span-5">Título</div>
                  <div className="col-span-2">Autor</div>
                  <div className="col-span-2">Fecha</div>
                  <div className="col-span-1">Estado</div>
                  <div className="col-span-2">Acciones</div>
                </div>
                
                {posts.map((post) => (
                  <div 
                    key={post.post_id} 
                    className={`admin-row grid grid-cols-12 gap-4 p-4 border-b border-[#262626]/10 items-center ${
                      post.is_moderated ? "opacity-50" : ""
                    }`}
                  >
                    <div className="col-span-5">
                      <Link 
                        to={`/post/${post.post_id}`}
                        className="font-body text-sm text-[#e5e5e5] hover:text-primary transition-colors line-clamp-1"
                      >
                        {post.title}
                      </Link>
                      <span className="font-ui text-xs text-[#737373]">
                        {post.category}
                      </span>
                    </div>
                    <div className="col-span-2 font-ui text-xs text-[#a3a3a3]">
                      {post.is_anonymous ? "Anónimo" : post.author_name}
                    </div>
                    <div className="col-span-2 font-ui text-xs text-[#737373]">
                      {formatDate(post.created_at)}
                    </div>
                    <div className="col-span-1">
                      {post.is_moderated ? (
                        <span className="text-red-500 font-ui text-xs">Oculto</span>
                      ) : (
                        <span className="text-green-500 font-ui text-xs">Visible</span>
                      )}
                    </div>
                    <div className="col-span-2 flex gap-2">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleModeratePost(post.post_id)}
                        className="text-[#a3a3a3] hover:text-[#e5e5e5] p-2"
                        title={post.is_moderated ? "Hacer visible" : "Ocultar"}
                      >
                        {post.is_moderated ? <Eye size={16} /> : <EyeOff size={16} />}
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleDeletePost(post.post_id)}
                        className="text-[#a3a3a3] hover:text-red-500 p-2"
                        title="Eliminar"
                      >
                        <Trash2 size={16} />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </TabsContent>

          {/* Users Tab */}
          <TabsContent value="users">
            {loadingUsers ? (
              <div className="space-y-2">
                {[1, 2, 3, 4, 5].map(i => (
                  <div key={i} className="skeleton h-16 w-full" />
                ))}
              </div>
            ) : users.length === 0 ? (
              <p className="font-ui text-[#737373] text-center py-8">No hay usuarios</p>
            ) : (
              <div className="bg-[#0a0a0a] border border-[#262626]/30">
                <div className="grid grid-cols-12 gap-4 p-4 border-b border-[#262626]/30 font-ui text-xs text-[#737373] uppercase tracking-wider">
                  <div className="col-span-4">Usuario</div>
                  <div className="col-span-3">Email</div>
                  <div className="col-span-2">Registro</div>
                  <div className="col-span-3">Rol</div>
                </div>
                
                {users.map((u) => (
                  <div 
                    key={u.user_id} 
                    className="admin-row grid grid-cols-12 gap-4 p-4 border-b border-[#262626]/10 items-center"
                  >
                    <div className="col-span-4 flex items-center gap-2">
                      {u.picture ? (
                        <img src={u.picture} alt={u.name} className="w-8 h-8 rounded-full object-cover" />
                      ) : (
                        <div className="w-8 h-8 rounded-full bg-[#171717] flex items-center justify-center">
                          <Users size={14} className="text-[#737373]" />
                        </div>
                      )}
                      <Link 
                        to={`/profile/${u.user_id}`}
                        className="font-ui text-sm text-[#e5e5e5] hover:text-primary transition-colors"
                      >
                        {u.name}
                      </Link>
                    </div>
                    <div className="col-span-3 font-ui text-xs text-[#a3a3a3] truncate">
                      {u.email}
                    </div>
                    <div className="col-span-2 font-ui text-xs text-[#737373]">
                      {formatDate(u.created_at)}
                    </div>
                    <div className="col-span-3">
                      {user.role === "admin" && u.user_id !== user.user_id ? (
                        <Select 
                          value={u.role || "user"} 
                          onValueChange={(value) => handleUpdateRole(u.user_id, value)}
                        >
                          <SelectTrigger className="input-dark h-8 text-xs">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent className="bg-[#0a0a0a] border-[#262626]">
                            <SelectItem value="user" className="text-[#d4d4d4]">Usuario</SelectItem>
                            <SelectItem value="moderator" className="text-[#d4d4d4]">Moderador</SelectItem>
                            <SelectItem value="admin" className="text-[#d4d4d4]">Admin</SelectItem>
                          </SelectContent>
                        </Select>
                      ) : (
                        <span className={`font-ui text-xs px-2 py-1 ${
                          u.role === "admin" ? "bg-primary/20 text-primary" :
                          u.role === "moderator" ? "bg-blue-500/20 text-blue-400" :
                          "bg-[#262626] text-[#a3a3a3]"
                        }`}>
                          {u.role || "user"}
                        </span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default AdminPage;
