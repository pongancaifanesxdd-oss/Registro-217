import { useEffect, useState, createContext, useContext } from "react";
import "@/App.css";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import axios from "axios";
import { Toaster } from "sonner";

// Pages
import HomePage from "./pages/HomePage";
import CategoryPage from "./pages/CategoryPage";
import EntryDetailPage from "./pages/EntryDetailPage";
import AboutPage from "./pages/AboutPage";
import AdminLoginPage from "./pages/AdminLoginPage";
import AdminDashboard from "./pages/AdminDashboard";
import CreateEntryPage from "./pages/CreateEntryPage";
import EditEntryPage from "./pages/EditEntryPage";

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
export const API = `${BACKEND_URL}/api`;

// Admin Auth Context
export const AdminContext = createContext(null);

export const useAdmin = () => {
  const context = useContext(AdminContext);
  if (!context) {
    throw new Error("useAdmin must be used within AdminProvider");
  }
  return context;
};

const AdminProvider = ({ children }) => {
  const [admin, setAdmin] = useState(null);
  const [loading, setLoading] = useState(true);

  const checkAdmin = async () => {
    try {
      const response = await axios.get(`${API}/admin/me`, {
        withCredentials: true
      });
      setAdmin(response.data);
    } catch (error) {
      setAdmin(null);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    checkAdmin();
  }, []);

  const login = (adminData) => {
    setAdmin(adminData);
  };

  const logout = async () => {
    try {
      await axios.post(`${API}/admin/logout`, {}, { withCredentials: true });
    } catch (error) {
      console.error("Logout error:", error);
    }
    setAdmin(null);
  };

  return (
    <AdminContext.Provider value={{ admin, loading, login, logout, checkAdmin }}>
      {children}
    </AdminContext.Provider>
  );
};

// Noise Overlay
const NoiseOverlay = () => <div className="noise-overlay" />;

function App() {
  return (
    <BrowserRouter>
      <AdminProvider>
        <div className="min-h-screen bg-[#050505]">
          <NoiseOverlay />
          <Toaster 
            position="bottom-right" 
            theme="dark"
            toastOptions={{
              style: {
                background: '#0a0a0a',
                border: '1px solid #262626',
                color: '#e5e5e5',
              },
            }}
          />
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/categoria/:categoryId" element={<CategoryPage />} />
            <Route path="/registro/:entryId" element={<EntryDetailPage />} />
            <Route path="/sobre-el-archivo" element={<AboutPage />} />
            <Route path="/admin" element={<AdminLoginPage />} />
            <Route path="/admin/dashboard" element={<AdminDashboard />} />
            <Route path="/admin/nuevo" element={<CreateEntryPage />} />
            <Route path="/admin/editar/:entryId" element={<EditEntryPage />} />
          </Routes>
        </div>
      </AdminProvider>
    </BrowserRouter>
  );
}

export default App;
